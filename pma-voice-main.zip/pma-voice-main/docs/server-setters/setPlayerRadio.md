## setPlayerRadio

## Description

Sets the players radio channel.

## Parameters

* **source**: The player to set the radio channel of
* **radioChannel**: the radio channel to set the player to 

```lua
exports['pma-voice']:setPlayerRadio(source, 1)
```